﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Linq
{
    class Incentive
    {
        public int EmployeeReffId { get; set; }
        public DateTime IncentiveDate { get; set; }
        public int IncentiveAmount { get; set; }
    }
}
